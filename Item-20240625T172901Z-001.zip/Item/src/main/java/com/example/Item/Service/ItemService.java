package com.example.Item.Service;

import com.example.Item.data.Item;
import com.example.Item.data.ItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service

public class ItemService {

    @Autowired
    public ItemRepository itemRepository;
    //private Object Cid;

    public List<Item> getAllItem() {
        List<Item> items = itemRepository.findAll();
        return items;
    }


    public Item getItemById(int Cid) {
        Optional<Item> item = itemRepository.findById(Cid);
        if ((item.isPresent())) {
            return item.get();
        }
        return null;
    }

    public  Item saveItem(Item item){
        return itemRepository.save(item);
    }

    public Item updateItem(Item item)
    {
        return itemRepository.save(item);
    }

    public  String deleteItem(int Cid){
        itemRepository.deleteById(Cid);
        return "Deleted";
    }

}

