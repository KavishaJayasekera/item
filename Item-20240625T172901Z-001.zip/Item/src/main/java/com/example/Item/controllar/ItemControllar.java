package com.example.Item.controllar;

import com.example.Item.Service.ItemService;
import com.example.Item.data.Item;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@RestController

public class ItemControllar {

    @Autowired
    private ItemService itemService;

    @GetMapping(path = "/itemdetails")
    public List<Item>getAllItem()
    {
        return itemService.getAllItem();
    }

   @GetMapping(path = "/itemdetails/{Cid}")
    public Item getItemById(@PathVariable int Cid)
   {
       return itemService.getItemById(Cid);
   }

   @PostMapping(path = "/itemdetails")
   public Item createItem(@RequestBody Item item)
   {
       return itemService.saveItem(item);
   }

   @PutMapping(path = "/itemdetails")
    public Item updateItem(@RequestBody Item item)
   {
       return itemService.updateItem(item);
   }

   @DeleteMapping(path = "/itemdetails/{Cid}")
    public String deleteItem(@PathVariable int Cid)
   {
       return itemService.deleteItem(Cid);
   }
}
