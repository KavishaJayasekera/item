package com.example.Item.data;

import javax.persistence.*;

@Entity
@Table(name = "itemdetails")
public class Item {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int Cid;

    @Column(name="Cname")
    private String Cname;


    @Column(name = "Cprice")
    private double Cprice;


    public int getCid() {
        return Cid;
    }

    public void setCid(int cid) {
        Cid = cid;
    }

    public String getCname() {
        return Cname;
    }

    public void setCname(String cname) {
        Cname = cname;
    }

    public double getCprice() {
        return Cprice;
    }

    public void setCprice(double cprice) {
        Cprice = cprice;
    }
}
